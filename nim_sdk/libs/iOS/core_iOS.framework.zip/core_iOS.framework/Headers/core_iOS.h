//
//  core_iOS.h
//  core_iOS
//
//  Created by dudu on 2020/1/3.
//

#import <Foundation/Foundation.h>

//! Project version number for core_iOS.
FOUNDATION_EXPORT double core_iOSVersionNumber;

//! Project version string for core_iOS.
FOUNDATION_EXPORT const unsigned char core_iOSVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <core_iOS/PublicHeader.h>


